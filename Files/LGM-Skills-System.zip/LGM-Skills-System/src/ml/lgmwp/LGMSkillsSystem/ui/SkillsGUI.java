package ml.lgmwp.LGMSkillsSystem.ui;

import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import ml.lgmwp.LGMSkillsSystem.components.Skills;
import ml.lgmwp.LGMSkillsSystem.managers.ProfileManager;

import static ml.lgmwp.LGMSkillsSystem.Utils.*;

public class SkillsGUI
{
	private ProfileManager profileManager;
	
	public static Inventory inv;
	public static String invName;
	public static int invSlots = 6*9;
	
	public SkillsGUI(ProfileManager profileManager)
	{
		invName = color("&8Skills menu");
		inv = Bukkit.createInventory(null, invSlots);
		this.profileManager = profileManager;
	}
	
	public Inventory getSkillsGUI(Player player, int loadSlot)
	{
		Inventory inventory = Bukkit.createInventory(null, invSlots, invName);
		
		Skills s = profileManager.getPlayerProfile(player.getUniqueId()).getSkills();
		
		if (s.getPoints() < 1) {
			createItemByte(inv, "potion", 0, s.getPoints(), 13, color("&aSkill points: 0"), "You can use the point to level up skills");
		} else  {
			createItemByte(inv, "experience_bottle", 0, s.getPoints(), 13, color("&aSkill points"), "You can use the point to level up skills");
		}
		
		if (loadSlot == -1 || loadSlot == 28) {
			createItemByte(inv, "golden_apple", 0, 1, 28, color("&cHealth &flvl: " + s.getHealth()), color("&7Total Health: &a"+(20+s.getHealth())+" HP"), color("&7Bonus Health: &8+ &e" + s.getHealth() + "HP"));
		}
		if (loadSlot == -1 || loadSlot == 29) {
			createItemByte(inv, "iron_chestplate", 0, 1, 29, color("&aDefense &flvl: " + s.getDefense()), color("&7Total Defense: &a" + s.getDefense()));
		}
		if (loadSlot == -1 || loadSlot == 30) {
			createItemByte(inv, "sugar", 0, 1, 30, color("&fAgility"), color("&7Base Agility: &a100%"));
		}
		if (loadSlot == -1 || loadSlot == 31) {
			createItemByte(inv, "enchanted_book", 0, 1, 31, color("&bIntelligence"), "Base Intelligence: " + color("&a10"));
		}
		if (loadSlot == -1 || loadSlot == 32) {
			createItemByte(inv, "blaze_powder", 0, 1, 32, color("&cStrength"), "Base Strength: " + color("&a1"));
		}
		if (loadSlot == -1 || loadSlot == 33) {
			createItemByte(inv, "nether_star", 0, 1, 33, color("&9Crit Chance"), "Base Crit Chance: " + color("&a10"));
		}
		if (loadSlot == -1 || loadSlot == 34) {
			createItemByte(inv, "diamond_sword", 0, 1, 34, color("&9Crit Damage"), "Base Crit Damage: " + color("&a10%"));
		}

		inventory.setContents(inv.getContents());
		
		return inventory;
	}
	
	public void Clicked(Player p, int slot, ItemStack clicked, Inventory inv)
	{
		Skills skills = profileManager.getPlayerProfile(p.getUniqueId()).getSkills();
		int points = skills.getPoints();
		
		if (points < 1) {
			return;
		}
		
		if (slot == 28) {
			skills.setPoints(points - 1);
			skills.setHealth(skills.getHealth() + 1);
			p.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(20D + skills.getHealth());
		}
		else if (slot == 29) {
			skills.setPoints(points - 1);
			skills.setDefenseh(skills.getDefense() + 1);
		}
		else if (slot == 30) {
			skills.setPoints(points - 1);
			skills.setAgility(skills.getAgility() + 1);
			p.setWalkSpeed((float)(0.2 + ((skills.getAgility() / 10) * 0.2)));
		}
		else if (slot == 31) {
			skills.setPoints(points - 1);
			skills.setIntelligence(skills.getIntelligence() + 1);
		}
		else if (slot == 32) {
			skills.setPoints(points - 1);
			skills.setStrength(skills.getStrength() + 1);
		}
		else if (slot == 33) {
			skills.setPoints(points - 1);
			skills.setCritChance(skills.getCritChance() + 1);
		}
		else if (slot == 34) {
			skills.setPoints(points - 1);
			skills.setCritDamage(skills.getCritChance() + 1);
		}
		
		if (slot == 28 || slot == 29 || slot == 30 || slot == 31 || slot == 32 || slot == 33 || slot == 34 ) {
			p.openInventory(getSkillsGUI(p, slot));	
		}
	}
}
