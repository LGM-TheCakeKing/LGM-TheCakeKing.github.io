package ml.lgmwp.LGMSkillsSystem.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import ml.lgmwp.LGMSkillsSystem.Main;
import ml.lgmwp.LGMSkillsSystem.Utils;
import ml.lgmwp.LGMSkillsSystem.components.Profile;
import ml.lgmwp.LGMSkillsSystem.managers.ProfileManager;

public class JoinListener implements Listener
{
	private Main main;
	private ProfileManager profileManager;
	
	public JoinListener(Main main)
	{
		this.main = main;
		profileManager = main.getProfileManager();
	}
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event)
	{
		Player p = event.getPlayer();
		Profile profile = profileManager.getPlayerProfile(p.getUniqueId());//Check if player has a profile
		if (profile == null)
		{//New player
			profile = profileManager.createNewProfile(p);
			Utils.log(p.getName() + " has been add to LGM-S-S-Profiles!");
		}
	}
}
