package ml.lgmwp.LGMSkillsSystem.listeners;

import static ml.lgmwp.LGMSkillsSystem.Utils.color;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import ml.lgmwp.LGMSkillsSystem.Main;
import ml.lgmwp.LGMSkillsSystem.ui.SkillsGUI;

public class InventoryClickListener implements Listener
{
	private SkillsGUI skillsGUI;

	public InventoryClickListener(Main main)
	{
		skillsGUI = main.getSkillsGUI();
	}
	
	@EventHandler
	public void onInvClick(InventoryClickEvent e)
	{
		String title = e.getView().getTitle();
		
		e.getWhoClicked().sendMessage(title);
		e.getWhoClicked().sendMessage(color("&8Skills menu"));
		if (title.equals(color("&8Skills menu")))
		{
			e.setCancelled(true);
			skillsGUI.Clicked((Player) e.getWhoClicked(), e.getSlot(), e.getCurrentItem(), e.getInventory());
		}
	}
}
