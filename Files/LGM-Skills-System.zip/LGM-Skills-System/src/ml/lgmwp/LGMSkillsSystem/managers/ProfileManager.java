package ml.lgmwp.LGMSkillsSystem.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;

import ml.lgmwp.LGMSkillsSystem.Main;
import ml.lgmwp.LGMSkillsSystem.components.Profile;
import ml.lgmwp.LGMSkillsSystem.components.Skills;

public class ProfileManager
{
	private Map<UUID, Profile> profiles = new HashMap<>();
	
	private Main main;
	public ProfileManager(Main main)
	{
		this.main = main;
	}
	
	public Profile createNewProfile(Player player)
	{
		Skills startSkills = new Skills(10, 0, 0, 0, 0, 0, 0, 0);
		Profile profile = new Profile(startSkills);
		profiles.put(player.getUniqueId(), profile);
		return profile;
	}
	
	public Profile getPlayerProfile(UUID uuid)
	{
		return profiles.get(uuid);
	}
}
