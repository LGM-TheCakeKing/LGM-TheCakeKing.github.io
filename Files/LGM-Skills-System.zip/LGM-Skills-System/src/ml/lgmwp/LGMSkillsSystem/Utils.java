package ml.lgmwp.LGMSkillsSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Utils
{
	private static Logger logger = Main.getPluginLogger();

	public static void log(String... messages) {
		for (String message : messages) {
			logger.info(message);
		}
	}
	
	public static void warn(String... messages) {
		for (String message : messages) {
			logger.info(message);
		}
	}
	
	public static void error(String... messages) {
		for (String message : messages) {
			logger.info(message);
		}
	}
	
	public static String color(String text)
	{
		return ChatColor.translateAlternateColorCodes('&', text);
	}
	
	public static ItemStack createItemByte(Inventory inv, String materialName, int byteId, int amount, int invSlot, String displayName, String... loreString)
	{
		if (amount == 0) {
			amount = 1;
			warn("Amount is 0");
		}
		
		ItemStack item;
		List<String> lore = new ArrayList<String>();
		
		item = new ItemStack(Material.matchMaterial(materialName), amount); //, (short) byteId
		
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(color(displayName));
		for (String s : loreString)
		{
			lore.add(color(s));
		}
		meta.setLore(lore);
		item.setItemMeta(meta);
		inv.setItem(invSlot, item);
		
		return item;
	}
}
