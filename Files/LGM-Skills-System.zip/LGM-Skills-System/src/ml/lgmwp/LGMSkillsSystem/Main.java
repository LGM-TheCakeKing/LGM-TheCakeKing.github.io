package ml.lgmwp.LGMSkillsSystem;

import java.util.logging.Logger;

import org.bukkit.plugin.java.JavaPlugin;

import ml.lgmwp.LGMSkillsSystem.commands.SkillCommand;
import ml.lgmwp.LGMSkillsSystem.listeners.InventoryClickListener;
import ml.lgmwp.LGMSkillsSystem.listeners.JoinListener;
import ml.lgmwp.LGMSkillsSystem.managers.ProfileManager;
import ml.lgmwp.LGMSkillsSystem.ui.SkillsGUI;

public class Main extends JavaPlugin
{
	private static Logger logger;
	private ProfileManager profileManager;
	private SkillsGUI skillsGUI;
	
	@Override
	public void onEnable()
	{
		logger = getLogger();
		profileManager = new ProfileManager(this);
		skillsGUI = new SkillsGUI(profileManager);
		SkillCommand skillCommand = new SkillCommand(this);
		getCommand("skills").setExecutor(skillCommand);
		getServer().getPluginManager().registerEvents(new JoinListener(this), this);
		getServer().getPluginManager().registerEvents(new InventoryClickListener(this), this);
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	public static Logger getPluginLogger()
	{
		return logger;
	}
	
	public ProfileManager getProfileManager()
	{
		return profileManager;
	}
	
	public SkillsGUI getSkillsGUI()
	{
		return skillsGUI;
	}
}
