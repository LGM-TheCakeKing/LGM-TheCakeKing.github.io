package ml.lgmwp.LGMSkillsSystem.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import ml.lgmwp.LGMSkillsSystem.Main;
import ml.lgmwp.LGMSkillsSystem.Utils;
import ml.lgmwp.LGMSkillsSystem.ui.SkillsGUI;

public class SkillCommand implements CommandExecutor
{
	private SkillsGUI skillsGUI;

	public SkillCommand(Main main)
	{
		skillsGUI = main.getSkillsGUI();
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] arg3)
	{
		if (!(sender instanceof Player))
		{
			Utils.log("this command only works for player");
			return true;
		}
		
		Player p = (Player) sender;
		
		p.openInventory(skillsGUI.getSkillsGUI(p, -1));
		
		return true;
	}
}
